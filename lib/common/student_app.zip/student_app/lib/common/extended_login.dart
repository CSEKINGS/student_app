import 'package:flutter/material.dart';

class ExtendedLogin extends StatefulWidget {
  @override
  _ExtendedLoginState createState() => _ExtendedLoginState();
}

class _ExtendedLoginState extends State<ExtendedLogin> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
