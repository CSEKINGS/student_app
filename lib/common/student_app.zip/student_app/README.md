# student-app

An app to digitalize the counselling works in a cross-platform application.

How to contribute: 
1. Fork the repository.
2. Make changes that you feel would not conflict with other modules.
3. Create a pull request mentioning what you did.
4. All requests will be accepted within 12 hrs.

Issues:
1. Make sure to test various devices before creating a ticket.
2. Specify the log and device descriptions. Otherwise, issue will be closed.

**Note: Only Android is supported right now.**
